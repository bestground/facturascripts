#
# Respaldo de Base de Datos MySQL
# Creada con la clase MySQL_Backup - Versión. 1.0.1b
# (Adaptada y traducida por Valentín González)
#
# Servidor: localhost
# Generada el: 20/01/2015 a las 03:22:28
# Versión de MySQL: 5.5.32
# Versión de PHP: 5.4.20
#
# Base de Datos: `facturascripts`
#


SET FOREIGN_KEY_CHECKS=0;


#
# Estructura de la tabla `agentes`
#

DROP TABLE IF EXISTS `agentes`;
CREATE TABLE `agentes` (
  `apellidos` varchar(100) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `coddepartamento` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dnicif` varchar(15) COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `idusuario` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `nombreap` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codagente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `agentes`
#

INSERT INTO agentes VALUES ('Pepe', '', '1', '', '', '', '', '00000014Z', '', '', '', '', '', 'Paco', '', '', '', '');


#
# Estructura de la tabla `albaranescli`
#

DROP TABLE IF EXISTS `albaranescli`;
CREATE TABLE `albaranescli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(12) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time DEFAULT '00:00:00',
  `idalbaran` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombrecliente` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  `total_bruto` double NOT NULL DEFAULT '0',
  `importe_iva` double NOT NULL DEFAULT '0',
  `total_factura` double NOT NULL DEFAULT '0',
  `pago_senor` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idalbaran`),
  UNIQUE KEY `uniq_codigo_albaranescli` (`codigo`),
  KEY `ca_albaranescli_series2` (`codserie`),
  KEY `ca_albaranescli_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_albaranescli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranescli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `albaranescli`
#

INSERT INTO albaranescli VALUES ('', '9778568a', 'León', '1', 'ALG', '000001', '1', 'EUR', '0001', '00010A000015', 'CONT', 'ESP', '24007', 'A', 'C/ Padre Risco', '2015-01-20', '02:22:16', '15', '', '', '0', '0', 'cliente prueba', '15', '', '', '0', 'León', '1', '0', '1', '0', '0', '0', '0', '0', '22.14', '4.65', '26.79', '61.76');
INSERT INTO albaranescli VALUES ('', '9778568a', 'León', '1', 'ALG', '000001', '1', 'EUR', '0001', '00010A000016', 'CONT', 'ESP', '24007', 'A', 'C/ Padre Risco', '2015-01-20', '02:23:12', '16', '', '', '0', '265.65', 'cliente prueba', '16', '', '', '0', 'León', '1', '0', '1', '265.65', '265.65', '0', '0', '0', '66.41', '13.95', '80.36', '185.29');


#
# Estructura de la tabla `albaranesprov`
#

DROP TABLE IF EXISTS `albaranesprov`;
CREATE TABLE `albaranesprov` (
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(12) COLLATE utf8_bin NOT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idalbaran` int(11) NOT NULL AUTO_INCREMENT,
  `idfactura` int(11) DEFAULT NULL,
  `irpf` double NOT NULL DEFAULT '0',
  `neto` double NOT NULL DEFAULT '0',
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `ptefactura` tinyint(1) NOT NULL DEFAULT '1',
  `recfinanciero` double NOT NULL DEFAULT '0',
  `tasaconv` double NOT NULL DEFAULT '1',
  `total` double NOT NULL DEFAULT '0',
  `totaleuros` double NOT NULL DEFAULT '0',
  `totalirpf` double NOT NULL DEFAULT '0',
  `totaliva` double NOT NULL DEFAULT '0',
  `totalrecargo` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idalbaran`),
  UNIQUE KEY `uniq_codigo_albaranesprov` (`codigo`),
  KEY `ca_albaranesprov_series2` (`codserie`),
  KEY `ca_albaranesprov_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_albaranesprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_albaranesprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `albaranesprov`
#



#
# Estructura de la tabla `almacenes`
#

DROP TABLE IF EXISTS `almacenes`;
CREATE TABLE `almacenes` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `observaciones` text COLLATE utf8_bin,
  `poblacion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `porpvp` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `telefono` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tipovaloracion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codalmacen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `almacenes`
#

INSERT INTO almacenes VALUES ('', 'ALG', '', '', '', '', '', '', 'ALMACEN GENERAL', '', '', '', '', '', '');


#
# Estructura de la tabla `articulos`
#

DROP TABLE IF EXISTS `articulos`;
CREATE TABLE `articulos` (
  `factualizado` date DEFAULT NULL,
  `destacado` tinyint(1) DEFAULT '0',
  `bloqueado` tinyint(1) DEFAULT '0',
  `equivalencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentairpfcom` int(11) DEFAULT NULL,
  `idsubcuentacom` int(11) DEFAULT NULL,
  `stockmin` double DEFAULT '0',
  `observaciones` text COLLATE utf8_bin,
  `codbarras` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `stockfis` double DEFAULT '0',
  `stockmax` double DEFAULT '0',
  `costemedio` double DEFAULT '0',
  `preciocoste` double DEFAULT '0',
  `tipocodbarras` varchar(8) COLLATE utf8_bin DEFAULT 'Code39',
  `nostock` tinyint(1) DEFAULT NULL,
  `codsubcuentacom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin NOT NULL,
  `codsubcuentairpfcom` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `secompra` tinyint(1) DEFAULT NULL,
  `codfamilia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `imagen` text COLLATE utf8_bin,
  `controlstock` tinyint(1) DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `pvp` double DEFAULT '0',
  `sevende` tinyint(1) DEFAULT NULL,
  `publico` tinyint(1) DEFAULT '0',
  `dueno` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `telefonodueno` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipodni` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `fentrada` date DEFAULT NULL,
  `fsalida` date DEFAULT NULL,
  PRIMARY KEY (`referencia`),
  KEY `ca_articulos_impuestos2` (`codimpuesto`),
  CONSTRAINT `ca_articulos_impuestos2` FOREIGN KEY (`codimpuesto`) REFERENCES `impuestos` (`codimpuesto`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `articulos`
#

INSERT INTO articulos VALUES ('2015-01-19', '0', '0', '', '', '', '0', '', '', 'IVA21', '0', '0', '0', '0', 'Code39', '', '', 'REF3', '', '1', 'VARI', '', '1', 'REF3', '88.55', '1', '0', '', '', '', '2015-01-18', '2015-01-18');


#
# Estructura de la tabla `articulostarifas`
#

DROP TABLE IF EXISTS `articulostarifas`;
CREATE TABLE `articulostarifas` (
  `codtarifa` varchar(6) COLLATE utf8_bin NOT NULL,
  `descuento` double NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pvp` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_articulostarifas_tarif_ref` (`codtarifa`,`referencia`),
  KEY `ca_articulostarifas_articulos2` (`referencia`),
  CONSTRAINT `ca_articulostarifas_articulos2` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_articulostarifas_tarifas2` FOREIGN KEY (`codtarifa`) REFERENCES `tarifas` (`codtarifa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `articulostarifas`
#



#
# Estructura de la tabla `cajas`
#

DROP TABLE IF EXISTS `cajas`;
CREATE TABLE `cajas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fs_id` int(11) NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin NOT NULL,
  `f_inicio` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `d_inicio` double NOT NULL DEFAULT '0',
  `f_fin` timestamp NULL DEFAULT NULL,
  `d_fin` double DEFAULT NULL,
  `tickets` int(11) DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_cajas_agentes2` (`codagente`),
  CONSTRAINT `ca_cajas_agentes2` FOREIGN KEY (`codagente`) REFERENCES `agentes` (`codagente`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `cajas`
#

INSERT INTO cajas VALUES ('1', '1', '1', '2015-01-18 21:10:13', '0', '', '0', '0', '::1');


#
# Estructura de la tabla `clientes`
#

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `capitalimpagado` double DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codtiporappel` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `copiasfactura` int(11) DEFAULT NULL,
  `debaja` tinyint(1) DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `fechabaja` date DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaincluido` tinyint(1) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombrecomercial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recargo` tinyint(1) DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `riesgoalcanzado` double DEFAULT NULL,
  `riesgomax` double DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `clientes`
#

INSERT INTO clientes VALUES ('', '9778568a', '', '000001', '', '', '', 'EUR', '', '', 'CONT', 'A', '', '', '', '', '0', '', '', '', '', '', 'cliente prueba', 'cliente prueba', '', '0', 'General', '', '', '', '', 'NIF', '');


#
# Estructura de la tabla `co_asientos`
#

DROP TABLE IF EXISTS `co_asientos`;
CREATE TABLE `co_asientos` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codplanasiento` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `documento` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `editable` tinyint(1) NOT NULL,
  `fecha` date NOT NULL,
  `idasiento` int(11) NOT NULL AUTO_INCREMENT,
  `idconcepto` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `importe` double DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `tipodocumento` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idasiento`),
  KEY `ca_co_asientos_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_co_asientos_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_asientos`
#



#
# Estructura de la tabla `co_codbalances08`
#

DROP TABLE IF EXISTS `co_codbalances08`;
CREATE TABLE `co_codbalances08` (
  `descripcion4ba` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `descripcion4` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel4` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion3` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `orden3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `nivel3` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `descripcion2` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel2` int(11) DEFAULT NULL,
  `descripcion1` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nivel1` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `naturaleza` varchar(15) COLLATE utf8_bin NOT NULL,
  `codbalance` varchar(15) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codbalance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_codbalances08`
#



#
# Estructura de la tabla `co_conceptospar`
#

DROP TABLE IF EXISTS `co_conceptospar`;
CREATE TABLE `co_conceptospar` (
  `concepto` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idconceptopar` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idconceptopar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_conceptospar`
#



#
# Estructura de la tabla `co_cuentas`
#

DROP TABLE IF EXISTS `co_cuentas`;
CREATE TABLE `co_cuentas` (
  `codbalance` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `idcuentaesp` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL,
  PRIMARY KEY (`idcuenta`),
  KEY `ca_co_cuentas_ejercicios` (`codejercicio`),
  KEY `ca_co_cuentas_epigrafes2` (`idepigrafe`),
  CONSTRAINT `ca_co_cuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_cuentas_epigrafes2` FOREIGN KEY (`idepigrafe`) REFERENCES `co_epigrafes` (`idepigrafe`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_cuentas`
#



#
# Estructura de la tabla `co_cuentasesp`
#

DROP TABLE IF EXISTS `co_cuentasesp`;
CREATE TABLE `co_cuentasesp` (
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idcuentaesp` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idcuentaesp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_cuentasesp`
#



#
# Estructura de la tabla `co_epigrafes`
#

DROP TABLE IF EXISTS `co_epigrafes`;
CREATE TABLE `co_epigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codepigrafe` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idepigrafe` int(11) NOT NULL AUTO_INCREMENT,
  `idgrupo` int(11) DEFAULT NULL,
  `idpadre` int(11) DEFAULT NULL,
  PRIMARY KEY (`idepigrafe`),
  KEY `ca_co_epigrafes_ejercicios` (`codejercicio`),
  KEY `ca_co_epigrafes_gruposepigrafes2` (`idgrupo`),
  CONSTRAINT `ca_co_epigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_epigrafes_gruposepigrafes2` FOREIGN KEY (`idgrupo`) REFERENCES `co_gruposepigrafes` (`idgrupo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_epigrafes`
#



#
# Estructura de la tabla `co_gruposepigrafes`
#

DROP TABLE IF EXISTS `co_gruposepigrafes`;
CREATE TABLE `co_gruposepigrafes` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `idgrupo` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idgrupo`),
  KEY `ca_co_gruposepigrafes_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_co_gruposepigrafes_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_gruposepigrafes`
#



#
# Estructura de la tabla `co_regiva`
#

DROP TABLE IF EXISTS `co_regiva`;
CREATE TABLE `co_regiva` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `fechaasiento` date NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `idasiento` int(11) NOT NULL,
  `idregiva` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `periodo` varchar(8) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idregiva`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_regiva`
#



#
# Estructura de la tabla `co_secuencias`
#

DROP TABLE IF EXISTS `co_secuencias`;
CREATE TABLE `co_secuencias` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `idsecuencia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL,
  PRIMARY KEY (`idsecuencia`),
  KEY `ca_co_secuencias_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_co_secuencias_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_secuencias`
#



#
# Estructura de la tabla `co_subcuentas`
#

DROP TABLE IF EXISTS `co_subcuentas`;
CREATE TABLE `co_subcuentas` (
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `debe` double NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `haber` double NOT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `idsubcuenta` int(11) NOT NULL AUTO_INCREMENT,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  `saldo` double NOT NULL,
  PRIMARY KEY (`idsubcuenta`),
  KEY `ca_co_subcuentas_ejercicios` (`codejercicio`),
  KEY `ca_co_subcuentas_cuentas2` (`idcuenta`),
  CONSTRAINT `ca_co_subcuentas_cuentas2` FOREIGN KEY (`idcuenta`) REFERENCES `co_cuentas` (`idcuenta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_co_subcuentas_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_subcuentas`
#



#
# Estructura de la tabla `co_subcuentascli`
#

DROP TABLE IF EXISTS `co_subcuentascli`;
CREATE TABLE `co_subcuentascli` (
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsubcuenta` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_co_subcuentascli_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_co_subcuentascli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `co_subcuentascli`
#



#
# Estructura de la tabla `cuentasbanco`
#

DROP TABLE IF EXISTS `cuentasbanco`;
CREATE TABLE `cuentasbanco` (
  `sufijo` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin NOT NULL,
  `idsubcuentaecgc` int(11) DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin NOT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaecgc` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `cuentasbanco`
#



#
# Estructura de la tabla `cuentasbcocli`
#

DROP TABLE IF EXISTS `cuentasbcocli`;
CREATE TABLE `cuentasbcocli` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcuenta`),
  KEY `ca_cuentasbcocli_clientes` (`codcliente`),
  CONSTRAINT `ca_cuentasbcocli_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `cuentasbcocli`
#



#
# Estructura de la tabla `cuentasbcopro`
#

DROP TABLE IF EXISTS `cuentasbcopro`;
CREATE TABLE `cuentasbcopro` (
  `agencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `ctaagencia` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `ctaentidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `cuenta` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `entidad` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `iban` varchar(34) COLLATE utf8_bin DEFAULT NULL,
  `swift` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codcuenta`),
  KEY `ca_cuentasbcopro_proveedores` (`codproveedor`),
  CONSTRAINT `ca_cuentasbcopro_proveedores` FOREIGN KEY (`codproveedor`) REFERENCES `proveedores` (`codproveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `cuentasbcopro`
#



#
# Estructura de la tabla `dirclientes`
#

DROP TABLE IF EXISTS `dirclientes`;
CREATE TABLE `dirclientes` (
  `codcliente` varchar(6) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `domenvio` tinyint(1) DEFAULT NULL,
  `domfacturacion` tinyint(1) DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `ca_dirclientes_clientes` (`codcliente`),
  CONSTRAINT `ca_dirclientes_clientes` FOREIGN KEY (`codcliente`) REFERENCES `clientes` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `dirclientes`
#

INSERT INTO dirclientes VALUES ('000001', 'ESP', '', '', 'León', 'León', '24007', 'C/ Padre Risco', '1', '1', 'Principal', '1');


#
# Estructura de la tabla `divisas`
#

DROP TABLE IF EXISTS `divisas`;
CREATE TABLE `divisas` (
  `bandera` text COLLATE utf8_bin,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codiso` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `simbolo` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `tasaconv` double NOT NULL,
  PRIMARY KEY (`coddivisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `divisas`
#

INSERT INTO divisas VALUES ('', 'EUR', '978', 'EUROS', '', '€', '1');
INSERT INTO divisas VALUES ('', 'USD', '840', 'DÓLARES EE.UU.', '', '$', '1.36');


#
# Estructura de la tabla `ejercicios`
#

DROP TABLE IF EXISTS `ejercicios`;
CREATE TABLE `ejercicios` (
  `idasientocierre` int(11) DEFAULT NULL,
  `idasientopyg` int(11) DEFAULT NULL,
  `idasientoapertura` int(11) DEFAULT NULL,
  `plancontable` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `longsubcuenta` int(11) DEFAULT NULL,
  `estado` varchar(15) COLLATE utf8_bin NOT NULL,
  `fechafin` date NOT NULL,
  `fechainicio` date NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codejercicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `ejercicios`
#

INSERT INTO ejercicios VALUES ('', '', '', '08', '10', 'ABIERTO', '2015-12-31', '2015-01-01', '2015', '0001');


#
# Estructura de la tabla `empresa`
#

DROP TABLE IF EXISTS `empresa`;
CREATE TABLE `empresa` (
  `administrador` varchar(100) COLLATE utf8_bin NOT NULL,
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcuentarem` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codedi` varchar(17) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `contintegrada` tinyint(1) DEFAULT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email_firma` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email_password` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `horario` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idprovincia` int(11) DEFAULT NULL,
  `lema` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `logo` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombrecorto` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `pie_factura` text COLLATE utf8_bin,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recequivalencia` tinyint(1) DEFAULT NULL,
  `stockpedidos` tinyint(1) DEFAULT NULL,
  `telefono` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `web` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `empresa`
#

INSERT INTO empresa VALUES ('', '', '25444457-V', 'Zaragoza', 'ALG', '', 'EUR', '', '0001', 'CONT', 'ESP', '', 'A', '0', 'Pablo Remacha nº15', '', '', 'admin', '', '', '1', '', '', '', 'Vendetu', 'Vendetu', '', 'Zaragoza', '0', '0', '', '');


#
# Estructura de la tabla `facturascli`
#

DROP TABLE IF EXISTS `facturascli`;
CREATE TABLE `facturascli` (
  `apartado` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `automatica` tinyint(1) NOT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `ciudad` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `codcliente` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddir` int(11) DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(12) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codpais` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `codpostal` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) NOT NULL,
  `direccion` varchar(100) COLLATE utf8_bin NOT NULL,
  `editable` tinyint(1) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `idprovincia` int(11) DEFAULT NULL,
  `irpf` double NOT NULL,
  `neto` double NOT NULL,
  `nogenerarasiento` tinyint(1) NOT NULL,
  `nombrecliente` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numero2` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `provincia` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `recfinanciero` double NOT NULL,
  `tasaconv` double NOT NULL,
  `total` double NOT NULL,
  `totaleuros` double NOT NULL,
  `totalirpf` double NOT NULL,
  `totaliva` double NOT NULL,
  `totalrecargo` double DEFAULT NULL,
  `tpv` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `uniq_codigo_facturascli` (`codigo`),
  KEY `ca_facturascli_series2` (`codserie`),
  KEY `ca_facturascli_ejercicios2` (`codejercicio`),
  KEY `ca_facturascli_asiento2` (`idasiento`),
  CONSTRAINT `ca_facturascli_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_facturascli_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `facturascli`
#



#
# Estructura de la tabla `facturasprov`
#

DROP TABLE IF EXISTS `facturasprov`;
CREATE TABLE `facturasprov` (
  `automatica` tinyint(1) NOT NULL,
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codalmacen` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin NOT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codigo` varchar(12) COLLATE utf8_bin NOT NULL,
  `codigorect` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `deabono` tinyint(1) NOT NULL,
  `editable` tinyint(1) NOT NULL DEFAULT '0',
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT '00:00:00',
  `idasiento` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL AUTO_INCREMENT,
  `idfacturarect` int(11) DEFAULT NULL,
  `idpagodevol` int(11) DEFAULT NULL,
  `irpf` double DEFAULT NULL,
  `neto` double DEFAULT NULL,
  `nogenerarasiento` tinyint(1) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `numero` varchar(12) COLLATE utf8_bin NOT NULL,
  `numproveedor` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `pagada` tinyint(1) NOT NULL DEFAULT '0',
  `recfinanciero` double NOT NULL,
  `tasaconv` double NOT NULL,
  `total` double DEFAULT NULL,
  `totaleuros` double DEFAULT NULL,
  `totalirpf` double DEFAULT NULL,
  `totaliva` double DEFAULT NULL,
  `totalrecargo` double DEFAULT NULL,
  PRIMARY KEY (`idfactura`),
  UNIQUE KEY `uniq_codigo_facturasprov` (`codigo`),
  KEY `ca_facturasprov_series2` (`codserie`),
  KEY `ca_facturasprov_ejercicios2` (`codejercicio`),
  KEY `ca_facturasprov_asiento2` (`idasiento`),
  CONSTRAINT `ca_facturasprov_asiento2` FOREIGN KEY (`idasiento`) REFERENCES `co_asientos` (`idasiento`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON UPDATE CASCADE,
  CONSTRAINT `ca_facturasprov_series2` FOREIGN KEY (`codserie`) REFERENCES `series` (`codserie`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `facturasprov`
#



#
# Estructura de la tabla `familias`
#

DROP TABLE IF EXISTS `familias`;
CREATE TABLE `familias` (
  `descripcion` varchar(100) COLLATE utf8_bin NOT NULL,
  `codfamilia` varchar(4) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codfamilia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `familias`
#

INSERT INTO familias VALUES ('VARIOS', 'VARI');


#
# Estructura de la tabla `formaspago`
#

DROP TABLE IF EXISTS `formaspago`;
CREATE TABLE `formaspago` (
  `codpago` varchar(10) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `genrecibos` varchar(10) COLLATE utf8_bin NOT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `domiciliado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codpago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `formaspago`
#

INSERT INTO formaspago VALUES ('CONT', 'CONTADO', 'Emitidos', '', '0');


#
# Estructura de la tabla `fs_extensions2`
#

DROP TABLE IF EXISTS `fs_extensions2`;
CREATE TABLE `fs_extensions2` (
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `page_from` varchar(30) COLLATE utf8_bin NOT NULL,
  `page_to` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `text` text COLLATE utf8_bin,
  `params` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`,`page_from`),
  KEY `ca_fs_extensions2_fs_pages` (`page_from`),
  CONSTRAINT `ca_fs_extensions2_fs_pages` FOREIGN KEY (`page_from`) REFERENCES `fs_pages` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `fs_extensions2`
#

INSERT INTO fs_extensions2 VALUES ('albaranes_agente', 'ventas_albaranes', 'admin_agente', 'button', 'Albaranes de cliente', '');
INSERT INTO fs_extensions2 VALUES ('albaranes_articulo', 'ventas_albaranes', 'ventas_articulo', 'button', 'Albaranes de cliente', '');
INSERT INTO fs_extensions2 VALUES ('albaranes_cliente', 'ventas_albaranes', 'ventas_cliente', 'button', 'Albaranes', '');
INSERT INTO fs_extensions2 VALUES ('email_albaran', 'ventas_imprimir', 'ventas_albaran', 'email', 'Albarán simple', '&albaran=TRUE');
INSERT INTO fs_extensions2 VALUES ('email_factura', 'ventas_imprimir', 'ventas_factura', 'email', 'Factura simple', '&factura=TRUE&tipo=simple');
INSERT INTO fs_extensions2 VALUES ('imprimir_albaran', 'ventas_imprimir', 'ventas_albaran', 'pdf', 'Albarán simple', '&albaran=TRUE');
INSERT INTO fs_extensions2 VALUES ('imprimir_factura', 'ventas_imprimir', 'ventas_factura', 'pdf', 'Factura simple', '&factura=TRUE&tipo=simple');
INSERT INTO fs_extensions2 VALUES ('imprimir_factura_carta', 'ventas_imprimir', 'ventas_factura', 'pdf', 'Modelo carta', '&factura=TRUE&tipo=carta');
INSERT INTO fs_extensions2 VALUES ('imprimir_factura_firma', 'ventas_imprimir', 'ventas_factura', 'pdf', 'Factura con firma', '&factura=TRUE&tipo=firma');


#
# Estructura de la tabla `fs_logs`
#

DROP TABLE IF EXISTS `fs_logs`;
CREATE TABLE `fs_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) COLLATE utf8_bin NOT NULL,
  `detalle` varchar(128) COLLATE utf8_bin NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `usuario` varchar(12) COLLATE utf8_bin DEFAULT NULL,
  `ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `alerta` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `fs_logs`
#

INSERT INTO fs_logs VALUES ('1', 'login', 'Login correcto.', '2015-01-18 21:04:35', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('2', 'error', 'Empleado no encontrado.', '2015-01-18 21:05:26', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('3', 'error', 'Usuario no encontrado.', '2015-01-18 21:05:26', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('4', 'error', '¡albarán de proveedor no encontrado!', '2015-01-18 21:05:27', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('5', 'error', '¡Factura de proveedor no encontrada!', '2015-01-18 21:05:27', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('6', 'error', '¡Proveedor no encontrado!', '2015-01-18 21:05:27', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('7', 'error', 'Asiento no encontrado.', '2015-01-18 21:05:27', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('8', 'error', 'Balance no encontrado.', '2015-01-18 21:05:27', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('9', 'error', 'Cuenta no encontrada.', '2015-01-18 21:05:27', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('10', 'error', 'Ejercicio no encontrado.', '2015-01-18 21:05:28', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('11', 'error', 'Subcuenta no encontrada.', '2015-01-18 21:05:28', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('12', 'error', 'Memcache está deshabilitado y es necesario para continuar. Clase Memcache no encontrada. Debes
               <a target=\"_blank\"', '2015-01-18 21:05:28', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('13', 'error', '¡albarán de cliente no encontrado!', '2015-01-18 21:05:29', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('14', 'error', '¡albarán de cliente no encontrado!', '2015-01-18 21:05:29', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('15', 'error', 'Artículo no encontrado.', '2015-01-18 21:05:29', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('16', 'error', 'Artículo no encontrado.', '2015-01-18 21:05:29', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('17', 'error', '¡Cliente no encontrado!', '2015-01-18 21:05:30', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('18', 'error', '¡Cliente no encontrado!', '2015-01-18 21:05:30', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('19', 'error', '¡Factura de cliente no encontrada!', '2015-01-18 21:05:30', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('20', 'error', '¡Factura de cliente no encontrada!', '2015-01-18 21:05:30', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('21', 'error', 'Familia no encontrada.', '2015-01-18 21:05:30', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('22', 'error', 'Familia no encontrada.', '2015-01-18 21:05:30', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('23', 'error', '¡Imposible guardar la linea con referencia: REF3', '2015-01-19 21:35:47', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('24', 'error', '¡Imposible guardar la linea con referencia: REF3', '2015-01-19 21:37:17', 'admin', '::1', '0');
INSERT INTO fs_logs VALUES ('25', 'error', 'El total difiere entre el controlador y la vista (176 frente a ). Debes informar del error.', '2015-01-20 02:36:15', 'admin', '::1', '0');


#
# Estructura de la tabla `fs_pages`
#

DROP TABLE IF EXISTS `fs_pages`;
CREATE TABLE `fs_pages` (
  `name` varchar(30) COLLATE utf8_bin NOT NULL,
  `title` varchar(40) COLLATE utf8_bin NOT NULL,
  `folder` varchar(15) COLLATE utf8_bin NOT NULL,
  `version` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `show_on_menu` tinyint(1) NOT NULL DEFAULT '1',
  `important` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `fs_pages`
#

INSERT INTO fs_pages VALUES ('admin_agente', 'Empleado', 'admin', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('admin_agentes', 'Empleados', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_almacenes', 'Almacenes', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_config2', 'Configuración avanzada', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_divisas', 'Divisas', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_empresa', 'Empresa', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_info', 'Información del sistema', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_pages', 'Páginas', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_paises', 'Paises', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_plugins', 'Plugins', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('admin_user', 'Usuario', 'admin', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('admin_users', 'Usuarios', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('backup', 'Backups', 'admin', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('importar_familia', 'importar familia', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('informe_albaranes', 'Albaranes', 'informes', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('informe_articulos', 'Artículos', 'informes', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('informe_errores', 'Errores', 'informes', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('informe_facturas', 'Facturas', 'informes', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('nueva_compra', 'nueva compra', 'compras', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('nueva_venta', 'nueva venta', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('subcuenta_asociada', 'Asignar subcuenta...', 'contabilidad', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('tpv_caja', 'Caja', 'TPV', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('tpv_recambios', 'TPV Genérico', 'TPV', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('ventas_agrupar_albaranes', 'Agrupar albaranes', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('ventas_albaran', 'albarán de cliente', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('ventas_albaranes', 'Albaranes de cliente', 'ventas', '2014.12.4', '1', '1');
INSERT INTO fs_pages VALUES ('ventas_articulo', 'Articulo', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('ventas_articulos', 'Artículos', 'ventas', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('ventas_cliente', 'Cliente', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('ventas_clientes', 'Clientes', 'ventas', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('ventas_familia', 'Familia', 'ventas', '2014.12.4', '0', '0');
INSERT INTO fs_pages VALUES ('ventas_familias', 'Familias', 'ventas', '2014.12.4', '1', '0');
INSERT INTO fs_pages VALUES ('ventas_imprimir', 'imprimir', 'ventas', '2014.12.4', '0', '0');


#
# Estructura de la tabla `fs_users`
#

DROP TABLE IF EXISTS `fs_users`;
CREATE TABLE `fs_users` (
  `nick` varchar(12) COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_bin NOT NULL,
  `log_key` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `codagente` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `last_login` date DEFAULT NULL,
  `last_login_time` time DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `last_browser` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `fs_page` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `codejercicio` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`nick`),
  KEY `ca_fs_users_agentes2` (`codagente`),
  KEY `ca_fs_users_pages2` (`fs_page`),
  KEY `ca_fs_users_ejercicios2` (`codejercicio`),
  CONSTRAINT `ca_fs_users_agentes2` FOREIGN KEY (`codagente`) REFERENCES `agentes` (`codagente`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_fs_users_ejercicios2` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ca_fs_users_pages2` FOREIGN KEY (`fs_page`) REFERENCES `fs_pages` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `fs_users`
#

INSERT INTO fs_users VALUES ('admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '01c09f5d2c313ccfad4c117e8ee88e0a982fb5b1', '1', '1', '2015-01-20', '02:34:24', '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36', '', '0001');


#
# Estructura de la tabla `fs_vars`
#

DROP TABLE IF EXISTS `fs_vars`;
CREATE TABLE `fs_vars` (
  `name` varchar(35) COLLATE utf8_bin NOT NULL,
  `varchar` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `fs_vars`
#

INSERT INTO fs_vars VALUES ('first_time', '1');
INSERT INTO fs_vars VALUES ('mail_enc', 'ssl');
INSERT INTO fs_vars VALUES ('mail_host', 'smtp.gmail.com');
INSERT INTO fs_vars VALUES ('mail_port', '465');
INSERT INTO fs_vars VALUES ('mail_user', '');


#
# Estructura de la tabla `gruposclientes`
#

DROP TABLE IF EXISTS `gruposclientes`;
CREATE TABLE `gruposclientes` (
  `codgrupo` varchar(6) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codgrupo`),
  KEY `ca_gruposclientes_tarifas` (`codtarifa`),
  CONSTRAINT `ca_gruposclientes_tarifas` FOREIGN KEY (`codtarifa`) REFERENCES `tarifas` (`codtarifa`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `gruposclientes`
#



#
# Estructura de la tabla `impuestos`
#

DROP TABLE IF EXISTS `impuestos`;
CREATE TABLE `impuestos` (
  `codimpuesto` varchar(10) COLLATE utf8_bin NOT NULL,
  `codsubcuentaacr` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentadeu` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadedadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadevadue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivadeventue` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepexp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivarepre` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopagra` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopexe` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentaivasopimp` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentarep` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuentasop` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuentaacr` int(11) DEFAULT NULL,
  `idsubcuentadeu` int(11) DEFAULT NULL,
  `idsubcuentaivadedadue` int(11) DEFAULT NULL,
  `idsubcuentaivadevadue` int(11) DEFAULT NULL,
  `idsubcuentaivadeventue` int(11) DEFAULT NULL,
  `idsubcuentaivarepexe` int(11) DEFAULT NULL,
  `idsubcuentaivarepexp` int(11) DEFAULT NULL,
  `idsubcuentaivarepre` int(11) DEFAULT NULL,
  `idsubcuentaivasopagra` int(11) DEFAULT NULL,
  `idsubcuentaivasopexe` int(11) DEFAULT NULL,
  `idsubcuentaivasopimp` int(11) DEFAULT NULL,
  `idsubcuentarep` int(11) DEFAULT NULL,
  `idsubcuentasop` int(11) DEFAULT NULL,
  `iva` double NOT NULL,
  `recargo` double NOT NULL,
  PRIMARY KEY (`codimpuesto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `impuestos`
#

INSERT INTO impuestos VALUES ('IVA0', '', '', '', '', '', '', '', '', '', '', '', '', '', 'IVA 0%', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0');
INSERT INTO impuestos VALUES ('IVA10', '', '', '', '', '', '', '', '', '', '', '', '', '', 'IVA 10%', '', '', '', '', '', '', '', '', '', '', '', '', '', '10', '1.4');
INSERT INTO impuestos VALUES ('IVA21', '', '', '', '', '', '', '', '', '', '', '', '', '', 'IVA 21%', '', '', '', '', '', '', '', '', '', '', '', '', '', '21', '5.2');
INSERT INTO impuestos VALUES ('IVA4', '', '', '', '', '', '', '', '', '', '', '', '', '', 'IVA 4%', '', '', '', '', '', '', '', '', '', '', '', '', '', '4', '0.5');


#
# Estructura de la tabla `lineasalbaranescli`
#

DROP TABLE IF EXISTS `lineasalbaranescli`;
CREATE TABLE `lineasalbaranescli` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dtolineal` double NOT NULL DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineapedido` int(11) NOT NULL DEFAULT '0',
  `idpedido` int(11) NOT NULL DEFAULT '0',
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `com_total` double NOT NULL DEFAULT '0',
  `com_porcentaje` double NOT NULL DEFAULT '0',
  `total_menos_comision` double NOT NULL DEFAULT '0',
  `com_iva` double NOT NULL DEFAULT '0',
  `neto_real` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineasalbaranescli_albaranescli2` (`idalbaran`),
  CONSTRAINT `ca_lineasalbaranescli_albaranescli2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranescli` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `lineasalbaranescli`
#

INSERT INTO lineasalbaranescli VALUES ('1', 'IVA0', 'REF3', '0', '0', '15', '1', '0', '0', '0', '0', '', '0', '0', '88.55', '0', 'REF3', '22.14', '25', '66.41', '4.65', '0');
INSERT INTO lineasalbaranescli VALUES ('2', 'IVA0', 'REF3', '0', '0', '16', '2', '0', '0', '0', '0', '', '177.1', '177.1', '88.55', '0', 'REF3', '44.27', '25', '132.83', '9.3', '0');
INSERT INTO lineasalbaranescli VALUES ('1', 'IVA0', 'REF3', '0', '0', '16', '3', '0', '0', '0', '0', '', '88.55', '88.55', '88.55', '0', 'REF3', '22.14', '25', '66.41', '4.65', '0');


#
# Estructura de la tabla `lineasalbaranesprov`
#

DROP TABLE IF EXISTS `lineasalbaranesprov`;
CREATE TABLE `lineasalbaranesprov` (
  `cantidad` double NOT NULL DEFAULT '0',
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dtolineal` double NOT NULL DEFAULT '0',
  `dtopor` double NOT NULL DEFAULT '0',
  `idalbaran` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `idlineapedido` int(11) NOT NULL DEFAULT '0',
  `idpedido` int(11) NOT NULL DEFAULT '0',
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL DEFAULT '0',
  `pvpsindto` double NOT NULL DEFAULT '0',
  `pvptotal` double NOT NULL DEFAULT '0',
  `pvpunitario` double NOT NULL DEFAULT '0',
  `recargo` double DEFAULT '0',
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_lineasalbaranesprov_albaranesprov2` (`idalbaran`),
  CONSTRAINT `ca_lineasalbaranesprov_albaranesprov2` FOREIGN KEY (`idalbaran`) REFERENCES `albaranesprov` (`idalbaran`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `lineasalbaranesprov`
#



#
# Estructura de la tabla `lineasfacturascli`
#

DROP TABLE IF EXISTS `lineasfacturascli`;
CREATE TABLE `lineasfacturascli` (
  `cantidad` double NOT NULL,
  `codimpuesto` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `dtolineal` double NOT NULL,
  `dtopor` double NOT NULL,
  `idalbaran` int(11) DEFAULT NULL,
  `idfactura` int(11) NOT NULL,
  `idlinea` int(11) NOT NULL AUTO_INCREMENT,
  `irpf` double DEFAULT NULL,
  `iva` double NOT NULL,
  `porcomision` double DEFAULT NULL,
  `pvpsindto` double NOT NULL,
  `pvptotal` double NOT NULL,
  `pvpunitario` double NOT NULL,
  `recargo` double DEFAULT NULL,
  `referencia` varchar(18) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idlinea`),
  KEY `ca_linea_facturascli2` (`idfactura`),
  CONSTRAINT `ca_linea_facturascli2` FOREIGN KEY (`idfactura`) REFERENCES `facturascli` (`idfactura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `lineasfacturascli`
#



#
# Estructura de la tabla `paises`
#

DROP TABLE IF EXISTS `paises`;
CREATE TABLE `paises` (
  `validarprov` tinyint(1) DEFAULT NULL,
  `codiso` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `bandera` text COLLATE utf8_bin,
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `codpais` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codpais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `paises`
#

INSERT INTO paises VALUES ('', 'AR', '', 'Argentina', 'ARG');
INSERT INTO paises VALUES ('', 'CL', '', 'Chile', 'CHL');
INSERT INTO paises VALUES ('', 'CO', '', 'Colombia', 'COL');
INSERT INTO paises VALUES ('', 'EC', '', 'Ecuador', 'ECU');
INSERT INTO paises VALUES ('', 'ES', '', 'España', 'ESP');
INSERT INTO paises VALUES ('', 'MX', '', 'México', 'MEX');
INSERT INTO paises VALUES ('', 'PA', '', 'Panamá', 'PAN');
INSERT INTO paises VALUES ('', 'VE', '', 'Venezuela', 'VEN');


#
# Estructura de la tabla `proveedores`
#

DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `cifnif` varchar(20) COLLATE utf8_bin NOT NULL,
  `codcontacto` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentadom` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `codcuentapago` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  `coddivisa` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `codpago` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `codproveedor` varchar(6) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin DEFAULT NULL,
  `codsubcuenta` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `idsubcuenta` int(11) DEFAULT NULL,
  `ivaportes` double DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombrecomercial` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `observaciones` text COLLATE utf8_bin,
  `recfinanciero` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `regimeniva` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `telefono1` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `telefono2` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `tipoidfiscal` varchar(25) COLLATE utf8_bin NOT NULL DEFAULT 'NIF',
  `web` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codproveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `proveedores`
#



#
# Estructura de la tabla `secuencias`
#

DROP TABLE IF EXISTS `secuencias`;
CREATE TABLE `secuencias` (
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id` int(11) NOT NULL,
  `idsec` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `valor` int(11) DEFAULT NULL,
  `valorout` int(11) DEFAULT NULL,
  PRIMARY KEY (`idsec`),
  KEY `ca_secuencias_secuenciasejercicios` (`id`),
  CONSTRAINT `ca_secuencias_secuenciasejercicios` FOREIGN KEY (`id`) REFERENCES `secuenciasejercicios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `secuencias`
#

INSERT INTO secuencias VALUES ('Secuencia del ejercicio 0001 y la serie A', '1', '1', 'nalbarancli', '1', '17');


#
# Estructura de la tabla `secuenciasejercicios`
#

DROP TABLE IF EXISTS `secuenciasejercicios`;
CREATE TABLE `secuenciasejercicios` (
  `codejercicio` varchar(4) COLLATE utf8_bin NOT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nalbarancli` int(11) NOT NULL,
  `nalbaranprov` int(11) NOT NULL,
  `nfacturacli` int(11) NOT NULL,
  `nfacturaprov` int(11) NOT NULL,
  `npedidocli` int(11) NOT NULL,
  `npedidoprov` int(11) NOT NULL,
  `npresupuestocli` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ca_secuenciasejercicios_ejercicios` (`codejercicio`),
  CONSTRAINT `ca_secuenciasejercicios_ejercicios` FOREIGN KEY (`codejercicio`) REFERENCES `ejercicios` (`codejercicio`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `secuenciasejercicios`
#

INSERT INTO secuenciasejercicios VALUES ('0001', 'A', '1', '1', '1', '1', '1', '1', '1', '1');


#
# Estructura de la tabla `series`
#

DROP TABLE IF EXISTS `series`;
CREATE TABLE `series` (
  `irpf` double DEFAULT NULL,
  `idcuenta` int(11) DEFAULT NULL,
  `codserie` varchar(2) COLLATE utf8_bin NOT NULL,
  `descripcion` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `siniva` tinyint(1) DEFAULT NULL,
  `codcuenta` varchar(6) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`codserie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `series`
#

INSERT INTO series VALUES ('0', '', 'A', 'SERIE A', '0', '');


#
# Estructura de la tabla `stocks`
#

DROP TABLE IF EXISTS `stocks`;
CREATE TABLE `stocks` (
  `referencia` varchar(18) COLLATE utf8_bin NOT NULL,
  `disponible` double NOT NULL,
  `stockmin` double NOT NULL DEFAULT '0',
  `reservada` double NOT NULL,
  `horaultreg` time DEFAULT '00:00:00',
  `nombre` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `pterecibir` double NOT NULL,
  `fechaultreg` date DEFAULT '2015-01-18',
  `codalmacen` varchar(4) COLLATE utf8_bin NOT NULL,
  `cantidadultreg` double NOT NULL DEFAULT '0',
  `idstock` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` double NOT NULL DEFAULT '0',
  `stockmax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`idstock`),
  UNIQUE KEY `uniq_stocks_almacen_referencia` (`codalmacen`,`referencia`),
  KEY `ca_stocks_articulos2` (`referencia`),
  CONSTRAINT `ca_stocks_almacenes3` FOREIGN KEY (`codalmacen`) REFERENCES `almacenes` (`codalmacen`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ca_stocks_articulos2` FOREIGN KEY (`referencia`) REFERENCES `articulos` (`referencia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `stocks`
#

INSERT INTO stocks VALUES ('REF3', '0', '0', '0', '00:00:00', '', '0', '2015-01-18', 'ALG', '0', '1', '0', '0');


#
# Estructura de la tabla `tarifas`
#

DROP TABLE IF EXISTS `tarifas`;
CREATE TABLE `tarifas` (
  `incporcentual` double NOT NULL,
  `inclineal` double NOT NULL DEFAULT '0',
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `codtarifa` varchar(6) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`codtarifa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# Volcado de datos de la tabla `tarifas`
#



SET FOREIGN_KEY_CHECKS=1;


